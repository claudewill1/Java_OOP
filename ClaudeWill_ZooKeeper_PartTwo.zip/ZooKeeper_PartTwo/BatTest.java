public class BatTest {
    public static void main(String[] args) {
        Bat aBat = new Bat();
        aBat.displayEnergy();
        aBat.attackTown();
        aBat.attackTown();
        aBat.fly();
        aBat.eatHumans();
        aBat.eatHumans();
        aBat.displayEnergy();
    }


}
