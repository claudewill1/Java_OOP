public class Mammal {
    public Integer energyLevel = 100;
    
    
    public Integer displayEnergy() {
        System.out.printf("Energy Level: %s.\n",energyLevel);
        return energyLevel;
    }
    

    
}
